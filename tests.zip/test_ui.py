"""IntelliBug UI tests (stage 2): login and a full valid submission."""
from pages.login_page import LoginPage
from pages.submit_bug_page import SubmitBugPage


def test_login_reaches_dashboard(driver, base_url):
    login_page = LoginPage(driver, base_url)
    login_page.login_as_demo()
    assert "IntelliBug" in driver.title


def test_submit_valid_bug_shows_severity_and_diagram(driver, base_url, test_image):
    LoginPage(driver, base_url).login_as_demo()

    submit_page = SubmitBugPage(driver, base_url)
    submit_page.open()
    submit_page.fill_form(
        title="Login button unresponsive on Safari",
        product="Customer Portal",
        environment="Safari 17, macOS",
        description="Expected: user reaches dashboard. Actual: nothing happens after clicking Login.",
    )
    submit_page.attach_screenshot(test_image)
    submit_page.submit()

    submit_page.wait_for_result()
    assert submit_page.get_severity() in ("Critical", "Medium", "Low")
    assert submit_page.count_flow_steps() >= 1
